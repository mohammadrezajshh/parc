package pro.kidsgaurd;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class ExplainItemActivity extends AppCompatActivity {

    ArrayList<String> aray = new ArrayList<String>();

    StringRequest stringRequest;
    RequestQueue requestQueue;
    RecyclerView recyclerViewDetail;
    ProgressDialog dialog = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(pro.kidsgaurd.R.layout.activity_explainitem);
        dialog = ProgressDialog.show(ExplainItemActivity.this, "please wait", "connecting to server...", true);
        recyclerViewDetail = (RecyclerView)findViewById(pro.kidsgaurd.R.id.recyclerViewDetailItem);
        Intent intent = getIntent();


        String msgIntent = intent.getStringExtra("IntentName");

        switch (msgIntent)
        {
            case "SMS Data":
                //Code Here

                StringRequest stringRequest=new StringRequest(Request.Method.POST,"https://req.kidsguard.pro/api/getSms/",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                dialog.dismiss();
                                try {

                                    JSONObject jsonsms=new JSONObject(response);
                                    String status=jsonsms.getString("status");

                                    switch (status){
                                        case "ok":

                                            JSONArray smsaray=jsonsms.getJSONArray("messages");
                                            int i=0;
                                            ArrayList<String> res=new ArrayList<String>();
                                            while (i<smsaray.length()){
                                                JSONObject conjs=smsaray.getJSONObject(i);
                                                String name=conjs.getString("number");
                                                String number=conjs.getString("body");
                                                String dir=conjs.getString("direction");
                                                res.add(name+":"+"\n"+number+"\n"+dir);

                                                i++;
                                            }

                                           recyclerViewDetail = (RecyclerView)findViewById(pro.kidsgaurd.R.id.recyclerViewDetailItem);
                                           recyclerViewAddList(getApplicationContext(),res,recyclerViewDetail);

                                            break;
                                        default:
                                            String message=jsonsms.getString("message");
                                            SendEror.sender(ExplainItemActivity.this,message);
                                            break;
                                    }

                                } catch (JSONException e) {
                                    dialog.dismiss();
                                    Toast.makeText(ExplainItemActivity.this, "e", Toast.LENGTH_LONG).show();
                                    e.printStackTrace();
                                    SendEror.sender(ExplainItemActivity.this,e.toString());


                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        dialog.dismiss();
                        Toast.makeText(ExplainItemActivity.this, "please check the connection", Toast.LENGTH_LONG).show();
                        SendEror.sender(ExplainItemActivity.this,error.toString());
                    }

                })
                {
                    @Override
                    protected Map<String, String> getParams(){
                        Map<String,String> params=new HashMap<String, String>();
                        params.put("parentToken",getowner(ExplainItemActivity.this));
                        params.put("childToken",getctoken(ExplainItemActivity.this));
                        return params;
                    }
                };
                RequestQueue requestQueue=Volley.newRequestQueue(ExplainItemActivity.this);
                requestQueue.add(stringRequest);

                break;

            case "Contact Data":
                //Code Here

                stringRequest=new StringRequest(Request.Method.POST,"https://req.kidsguard.pro/api/getContact/",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                dialog.dismiss();

                                try {
                                    JSONObject jsoncontact=new JSONObject(response);
                                    String status=jsoncontact.getString("status");

                                    switch (status){
                                        case "ok":
                                            JSONArray contactaray=jsoncontact.getJSONArray("contacts");
                                            ArrayList<String> res=new ArrayList<String>();
                                            int i=0;
                                            while (i<contactaray.length()){
                                                JSONObject conjs=contactaray.getJSONObject(i);
                                                String name=conjs.getString("name");
                                                String number=conjs.getString("tell");
                                                res.add(name+":"+"\n"+number);

                                                i++;
                                            }


                                            recyclerViewDetail = (RecyclerView)findViewById(pro.kidsgaurd.R.id.recyclerViewDetailItem);
                                            recyclerViewAddList(getApplicationContext(),res,recyclerViewDetail);


                                            break;
                                        default:
                                            String message=jsoncontact.getString("message");
                                            SendEror.sender(ExplainItemActivity.this,message);
                                            break;
                                    }

                                } catch (JSONException e) {
                                    dialog.dismiss();
                                    e.printStackTrace();
                                    SendEror.sender(ExplainItemActivity.this,e.toString());
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        dialog.dismiss();
                        Toast.makeText(ExplainItemActivity.this, "please check the connection", Toast.LENGTH_LONG).show();
                        SendEror.sender(ExplainItemActivity.this,error.toString());

                    }

                })
                {
                    @Override
                    protected Map<String, String> getParams(){
                        Map<String,String> params=new HashMap<String, String>();
                        params.put("parentToken",getowner(ExplainItemActivity.this));
                        params.put("childToken",getctoken(ExplainItemActivity.this));
                        return params;
                    }
                };
                requestQueue=Volley.newRequestQueue(ExplainItemActivity.this);
                requestQueue.add(stringRequest);

                break;

            case "Call Data":
                //Code Here

                stringRequest=new StringRequest(Request.Method.POST,"https://req.kidsguard.pro/api/getCall/",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                dialog.dismiss();
                                try {
                                    JSONObject jsoncall=new JSONObject(response);
                                    String status=jsoncall.getString("status");

                                    switch (status){
                                        case "ok":
                                            JSONArray callaray=jsoncall.getJSONArray("calls");
                                            ArrayList<String> res=new ArrayList<String>();
                                            int i=0;
                                            while (i<callaray.length()){
                                                JSONObject caljs=callaray.getJSONObject(i);
                                                String phNumber=caljs.getString("phnumber");
                                                String callDate=caljs.getString("calldate");
                                                Date callDayTime = new Date(Long.valueOf(callDate));
                                                String callDuration=caljs.getString("callduration");
                                                String dir=caljs.getString("dir");
                                                res.add("number: "+phNumber+"\n"+"date: "+callDayTime+"\n"+"duration: "+callDuration+"\n"+"direction: "+dir);

                                                i++;
                                            }


                                           recyclerViewDetail = (RecyclerView)findViewById(pro.kidsgaurd.R.id.recyclerViewDetailItem);
                                           recyclerViewAddList(getApplicationContext(),res,recyclerViewDetail);

                                            break;
                                        default:
                                            String message=jsoncall.getString("message");
                                            SendEror.sender(ExplainItemActivity.this,message);
                                            break;
                                    }

                                } catch (JSONException e) {
                                    dialog.dismiss();
                                    e.printStackTrace();
                                    SendEror.sender(ExplainItemActivity.this,e.toString());
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        dialog.dismiss();
                        Toast.makeText(ExplainItemActivity.this, "please check the connection", Toast.LENGTH_LONG).show();
                        SendEror.sender(ExplainItemActivity.this,error.toString());


                    }

                })
                {
                    @Override
                    protected Map<String, String> getParams(){
                        Map<String,String> params=new HashMap<String, String>();
                        params.put("parentToken",getowner(ExplainItemActivity.this));
                        params.put("childToken",getctoken(ExplainItemActivity.this));
                        return params;
                    }
                };
                requestQueue=Volley.newRequestQueue(ExplainItemActivity.this);
                requestQueue.add(stringRequest);

                break;

            case "InstalledPackage Data":
                //Code Here

                stringRequest=new StringRequest(Request.Method.POST,"https://req.kidsguard.pro/api/getPackages/",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                dialog.dismiss();
                                try {
                                    JSONObject alljs=new JSONObject(response);
                                    String status=alljs.getString("status");

                                    switch (status){
                                        case "ok":
                                            JSONArray pknamearay=alljs.getJSONArray("packs");
                                            ArrayList<String> res=new ArrayList<String>();
                                            int i=0;
                                            while (i<pknamearay.length()){
                                                JSONObject pjs=pknamearay.getJSONObject(i);
                                                String s=pjs.getString("name");
                                                res.add(s);
                                                i++;
                                            }


                                          recyclerViewDetail = (RecyclerView)findViewById(pro.kidsgaurd.R.id.recyclerViewDetailItem);
                                           recyclerViewAddList(ExplainItemActivity.this,res,recyclerViewDetail);

                                            break;
                                        default:
                                            String message=alljs.getString("message");
                                            SendEror.sender(ExplainItemActivity.this,message);
                                            break;
                                    }


                                } catch (JSONException e) {
                                    dialog.dismiss();
                                    e.printStackTrace();
                                    SendEror.sender(ExplainItemActivity.this,e.toString());
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        dialog.dismiss();
                        Toast.makeText(ExplainItemActivity.this, "please check the connection", Toast.LENGTH_LONG).show();
                        SendEror.sender(ExplainItemActivity.this,error.toString());

                    }

                })
                {
                    @Override
                    protected Map<String, String> getParams(){
                        Map<String,String> params=new HashMap<String, String>();
                        params.put("parentToken",getowner(ExplainItemActivity.this));
                        params.put("childToken",getctoken(ExplainItemActivity.this));
                        return params;
                    }
                };
                requestQueue=Volley.newRequestQueue(ExplainItemActivity.this);
                requestQueue.add(stringRequest);


                break;

        }



    }
    public String getctoken(Context context){
        CtokenDataBaseManager ctok=new CtokenDataBaseManager(context);
        return ctok.getctoken();
    }
    public String getowner(Context context){
        OwnerDataBaseManager owne=new OwnerDataBaseManager(context);
        return owne.getowner();
    }

    public void recyclerViewAddList(Context context , ArrayList<String> arrayList,RecyclerView recyclerView){
        RecyclerViewDetailItemAdapter adapter = new RecyclerViewDetailItemAdapter(context,arrayList);
        recyclerView.setAdapter(adapter);

        LayoutAnimationController animation =
                AnimationUtils.loadLayoutAnimation(context, pro.kidsgaurd.R.anim.layout_animation_slide_from_left);
        recyclerView.setLayoutAnimation(animation);

        LinearLayoutManager layoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(layoutManager);

    }

    @Override
    public void onBackPressed() {
        Intent intent=new Intent(this,WelcomeActivity.class);
        startActivity(intent);
    }
}
