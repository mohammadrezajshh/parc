package pro.kidsgaurd;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class BlockAppActivity extends AppCompatActivity {
    int a=0;
    RecyclerView recyclerViewAppLock;
    ProgressDialog dialog = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(pro.kidsgaurd.R.layout.activity_blockapp);
        dialog = ProgressDialog.show(BlockAppActivity.this, "please wait", "connecting to server...", true);
        recyclerViewAppLock = (RecyclerView)findViewById(pro.kidsgaurd.R.id.recyclerViewAppLock);
        getPackage(BlockAppActivity.this);



    }

    public void getPackage(final Context context){
        StringRequest stringRequest=new StringRequest(Request.Method.POST,"https://req.kidsguard.pro/api/getPackages/",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        dialog.dismiss();
                        try {
                            JSONObject alljs=new JSONObject(response);
                            String status=alljs.getString("status");

                            switch (status){
                                case "ok":
                                    JSONArray pknamearay=alljs.getJSONArray("packs");
                                    ArrayList<String> allpack=new ArrayList<String>();
                                    ArrayList<Boolean> lock=new ArrayList<Boolean>();
                                    ArrayList<String> firstTime=new ArrayList<String>();
                                    ArrayList<String> secondTime=new ArrayList<String>();
                                    int i=0;
                                    while (i<pknamearay.length()){
                                        JSONObject pjs=pknamearay.getJSONObject(i);
                                        String s=pjs.getString("packagename");
                                        allpack.add(s);
                                        lock.add(false);
                                        firstTime.add("");
                                        secondTime.add("");

                                        i++;

                                    }
                                    getblockPackage(context,allpack,lock,firstTime,secondTime);
                                    break;
                                default:
                                    String message=alljs.getString("message");
                                    SendEror.sender(BlockAppActivity.this,message);
                                    break;
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                            SendEror.sender(BlockAppActivity.this,e.toString());
                            dialog.dismiss();

                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
                Toast.makeText(context, "please check the connection", Toast.LENGTH_LONG).show();
                SendEror.sender(BlockAppActivity.this,error.toString());


            }

        })
        {
            @Override
            protected Map<String, String> getParams(){
                Map<String,String> params=new HashMap<String, String>();
                params.put("childToken",getctoken(context));
                return params;
            }
        };
        RequestQueue requestQueue=Volley.newRequestQueue(context);
        requestQueue.add(stringRequest);

    }
    public void getblockPackage(final Context context, final ArrayList<String> allpack, final ArrayList<Boolean> lock, final ArrayList<String> startTime, final ArrayList<String> endTime) {
        StringRequest stringRequest=new StringRequest(Request.Method.POST,"https://req.kidsguard.pro/api/getStatus/",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        dialog.dismiss();
                        JSONObject jsonstatus = null;
                        try {
                            jsonstatus = new JSONObject(response);
                            String status = jsonstatus.getString("status");
                            switch (status){
                                case "ok":
                                    try {

                                        JSONObject  appjson = jsonstatus.getJSONObject("packagesToLock");

                                        Iterator iter = appjson.keys();
                                        ArrayList<String> appName=new ArrayList<String>();
                                        while(iter.hasNext()){
                                            String pkgName = (String)iter.next();
                                            Toast.makeText(context, pkgName, Toast.LENGTH_LONG).show();
                                            JSONObject jstime=appjson.getJSONObject(pkgName);
                                            String ftime=jstime.getString("startTime");
                                            String stime=jstime.getString("endTime");
                                            if (allpack.contains(pkgName)){
                                            lock.set(allpack.indexOf(pkgName),true);
                                            startTime.set(allpack.indexOf(pkgName),ftime);
                                            endTime.set(allpack.indexOf(pkgName),stime);}

                                        }
                                        int i=0;
                                        while (i < allpack.size()) {
                                            String[] nam=allpack.get(i).split("\\.");
                                            int length=nam.length;

                                            appName.add(nam[length-1]);
                                            i++;

                                        }

                                        RecyclerViewAppLockAdapter adapter = new RecyclerViewAppLockAdapter(BlockAppActivity.this,lock,appName,startTime,endTime,allpack);
                                        recyclerViewAppLock.setAdapter(adapter);
                                        LayoutAnimationController animation =
                                                AnimationUtils.loadLayoutAnimation(context, pro.kidsgaurd.R.anim.layout_animation_fall_down);
                                        recyclerViewAppLock.setLayoutAnimation(animation);
                                        LinearLayoutManager layoutManager = new LinearLayoutManager(context);
                                        recyclerViewAppLock.setLayoutManager(layoutManager);

                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                        Toast.makeText(context, e.toString(), Toast.LENGTH_LONG).show();
                                        dialog.dismiss();
                                        SendEror.sender(BlockAppActivity.this,e.toString());

                                    }
                                    break;
                                default:
                                    String message=jsonstatus.getString("message");
                                    SendEror.sender(BlockAppActivity.this,message);
                                    break;
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();

                            dialog.dismiss();
                            SendEror.sender(BlockAppActivity.this,e.toString());

                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();

                SendEror.sender(BlockAppActivity.this,error.toString());



            }

        })
        {
            @Override
            protected Map<String, String> getParams(){
                Map<String,String> params=new HashMap<String, String>();
                params.put("token",getctoken(context));
                return params;
            }
        };
        RequestQueue requestQueue=Volley.newRequestQueue(context);
        requestQueue.add(stringRequest);

    }
    @Override
    public void onBackPressed() {

        alert();
    }


    public String getctoken(Context context){
        CtokenDataBaseManager ctok=new CtokenDataBaseManager(context);
        return ctok.getctoken();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if (id==android.R.id.home){
            alert();
        }
        return true;
    }
    public void alert(){
        AlertDialog.Builder Alert_close=new AlertDialog.Builder(BlockAppActivity.this);
        Alert_close.setTitle("warning").
                setMessage("Do you want to save changes?").
                setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        blockAppdb blockAppdb=new blockAppdb(BlockAppActivity.this);
                        JSONObject jsapp=new JSONObject();
                        ArrayList<String> appname=new ArrayList<String>();
                        if (blockAppdb.getjs().size()>0){
                        while (a<blockAppdb.getjs().size()){
                            String[] appblock=blockAppdb.getjs().get(a).split(":");
                            appname.add(appblock[0]);
                            String lock=appblock[1];
                            String ftime=appblock[2];
                            String stime=appblock[3];
                            JSONObject jsonObject=new JSONObject();
                            try {
                                jsonObject.put("lock",lock);
                                jsonObject.put("startTime",ftime);
                                jsonObject.put("endTime",stime);
                                jsapp.put(appblock[0],jsonObject);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                            a++;
                        }

                        blockIns blockIns=new blockIns();
                        String json= String.valueOf(jsapp);
                        blockIns.insblock(BlockAppActivity.this,json);
                        blockAppdb.delall();}
                        startActivity(new Intent(BlockAppActivity.this,WelcomeActivity.class));

                    }
                }).
                setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        blockAppdb blockAppdb=new blockAppdb(BlockAppActivity.this);
                        blockAppdb.delall();
                        startActivity(new Intent(BlockAppActivity.this,WelcomeActivity.class));
                        dialog.cancel();
                    }
                }).show();
    }

}
